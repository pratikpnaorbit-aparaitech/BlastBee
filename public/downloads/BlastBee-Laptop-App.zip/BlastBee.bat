@echo off
title BlastBee Desktop - Launching...
cd /d "%~dp0"
echo ====================================================
echo   🐝 BlastBee - Windows Laptop Desktop Application
echo   Developed by Aparaitech Software (aparaitech.org)
echo ====================================================
echo.
echo Starting local BlastBee engine...

:: Open standalone frameless App window via Microsoft Edge or Google Chrome
where msedge >nul 2>nul
if %errorlevel% equ 0 (
    start "" msedge --app=http://localhost:3000
) else (
    where chrome >nul 2>nul
    if %errorlevel% equ 0 (
        start "" chrome --app=http://localhost:3000
    ) else (
        start "" http://localhost:3000
    )
)

call start.bat
