@echo off
title Create BlastBee Desktop Shortcut
cd /d "%~dp0"
echo ====================================================
echo   Creating BlastBee Desktop Shortcut on your Laptop...
echo ====================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $desktop = [Environment]::GetFolderPath('Desktop'); $s = $ws.CreateShortcut([System.IO.Path]::Combine($desktop, 'BlastBee Email Engine.lnk')); $s.TargetPath = (Join-Path (Get-Location) 'BlastBee.bat'); $s.WorkingDirectory = (Get-Location).Path; $s.Description = 'BlastBee Email Outreach Engine for Windows Laptop'; $s.IconLocation = (Join-Path (Get-Location) 'public\assets\logo.svg'); $s.Save(); Write-Host '✅ Desktop Shortcut successfully created on your Windows Desktop!'"
echo.
echo [DONE] You can now launch BlastBee from your Desktop anytime!
echo.
pause
