============================================================
  🐝 BlastBee Email Outreach Engine - Windows Laptop App
  Developed by Aparaitech Software (https://aparaitech.org)
============================================================

Thank you for downloading the BlastBee Laptop Desktop Application!

QUICK 2-STEP SETUP:
------------------------------------------------------------
Step 1: Extract this ZIP file into any folder on your laptop
        (e.g., C:\BlastBee or Documents\BlastBee).

Step 2: Double-click "Create-Desktop-Shortcut.bat"
        - This puts the "BlastBee Email Engine" shortcut 
          directly on your Windows Desktop.

Step 3: Double-click "BlastBee.bat" or the Desktop Shortcut!
        - BlastBee will launch in a clean, standalone 
          Desktop Application window on your laptop.

DEFAULT LOGIN CREDENTIALS:
------------------------------------------------------------
• SuperAdmin Portal:
  URL: http://localhost:3000/admin
  Email: admin@aparaitech.org
  Password: admin123

• Customer Workspace:
  URL: http://localhost:3000/app
  Email: customer@example.com
  Password: customer123

SYSTEM REQUIREMENTS:
------------------------------------------------------------
• Windows 10 or Windows 11 (64-bit)
• Node.js LTS (https://nodejs.org)
• Internet connection for sending SMTP outreach campaigns

NEED HELP OR APPOINTMENT?
------------------------------------------------------------
WhatsApp Support: +91 9158852129
Email: support@aparaitech.org
Official Portal: https://aparaitech.org
============================================================
